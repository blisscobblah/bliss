var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');



const data = [
  {
    Fname: 'Bliss Cobblah',
    department: 'Human resource',
  },
  {
    Fname: 'John Essien',
    department: 'Project Manager'
  },
  {
    Fname: 'Frank Johnson',
    department: 'Sales',
  },
  {
    Fname: 'JOhn white',
    department: 'Marketing',
  }
]


/* GET Staffs page. */
router.get('/', function(req, res) {

  const url = 'mongodb://localhost:27017';
  const dbName = 'Staffdb';

(async function() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("Connected correctly to server");

    const db = client.db(dbName);

    // Insert multiple documents
    let r;
    r = await db.collection('Staffs').insertMany(data);
    assert.equal(data.length, r.insertedCount);

    const StaffList = await db.collection('Staffs').find().toArray()
    res.render('StaffList', { title: 'Staffs', StaffList });
  } catch (err) {
    console.log(err.stack);
  }
  await client.db(dbName).dropDatabase();
  // Close connection
  client.close();
})();
    
    
 
});

module.exports = router;
