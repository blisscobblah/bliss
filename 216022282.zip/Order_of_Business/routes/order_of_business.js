var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

const data = [
  {
    Duty: 'Check inventory',
    complete: true,
  },
  {
    Duty: 'Contact factory',
    complete: false
  },
  {
    Duty: 'prepare quarterly report',
    complete: true,
  },
  {
    Duty: 'prepare monthly sales report',
    complete: false,
  },
  {
   Duty: 'End of year party',
    complete: false,
  }
]


/* GET order_Of_Business page. */
router.get('/', function(req, res) {
  const url = 'mongodb://localhost:27017';
  const dbName = 'Staffdb';

(async function() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("Connected correctly to server");

    const db = client.db(dbName);

    // Insert multiple documents
    let r;
    r = await db.collection('orderOfBusiness').insertMany(data);
    assert.equal(data.length, r.insertedCount);

    const orderOfBusinessList = await db.collection('orderOfBusiness').find().toArray()
    res.render('orderOfBusiness', { title: 'Schedules', orderOfBusinessList });
  } catch (err) {
    console.log(err.stack);
  }
  await client.db(dbName).dropDatabase();
  // Close connection
  client.close();
})();
    
         

          
  });

module.exports = router;
