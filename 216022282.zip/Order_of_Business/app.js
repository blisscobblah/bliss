const express = require('express');
const logger = require('morgan');
const path = require('path');
const debug = require('debug')('app');

const employeesRoute = require('./routes/Staff');
const todoListRoute = require('./routes/order_of_business');

const app = express();
const port = 3000;

app.use(logger('dev'));
app.use(express.json());

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => res.render('index', { title: 'Home page'}))
app.use('/Staffs', employeesRoute);
app.use('/orderOfBusiness', todoListRoute);



app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))
